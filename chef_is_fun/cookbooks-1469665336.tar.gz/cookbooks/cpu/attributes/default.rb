default["cpu"]["governor"] = "ondemand"
