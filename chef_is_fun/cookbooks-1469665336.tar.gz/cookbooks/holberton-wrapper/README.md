# holberton-wrapper-cookbook

TODO: Enter the cookbook description here.

## Supported Platforms

TODO: List your supported platforms.

## Attributes

<table>
  <tr>
    <th>Key</th>
    <th>Type</th>
    <th>Description</th>
    <th>Default</th>
  </tr>
  <tr>
    <td><tt>['holberton-wrapper']['bacon']</tt></td>
    <td>Boolean</td>
    <td>whether to include bacon</td>
    <td><tt>true</tt></td>
  </tr>
</table>

## Usage

### holberton-wrapper::default

Include `holberton-wrapper` in your node's `run_list`:

```json
{
  "run_list": [
    "recipe[holberton-wrapper::default]"
  ]
}
```

## License and Authors

Author:: Bennett Buchanan (<bennett.buchanan@holbertonschool.com>)
