name "notifications"
description "cookbook that depends on compat_resource"
version "1.0.0"
depends "compat_resource"
